public class Coin : Item
{
}
