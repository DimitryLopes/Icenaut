
public class HealthPack : Item
{
    
}
