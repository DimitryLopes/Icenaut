using UnityEngine;
[CreateAssetMenu(fileName = "UsedItemState", menuName = "Scriptable Objects/Item States/Used Item Data")]
public class UsedItemState : ItemState
{
    public override void OnInteractionDisabled()
    {
    }

    public override void OnInteractionEnabled()
    {
    }
}
