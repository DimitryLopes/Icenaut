using UnityEngine;

[CreateAssetMenu(fileName = "GameFinishedGameState", menuName = "Scriptable Objects/GameFinishedGameState")]
public class GameFinishedGameState : GameState
{
}
