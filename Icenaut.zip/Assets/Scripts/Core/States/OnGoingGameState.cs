using UnityEngine;

[CreateAssetMenu(fileName = "OnGoingGameState", menuName = "Scriptable Objects/OnGoingGameState")]
public class OnGoingGameState : GameState
{
}
