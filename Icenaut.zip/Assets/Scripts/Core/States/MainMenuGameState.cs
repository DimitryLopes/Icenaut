using UnityEngine;

[CreateAssetMenu(fileName = "MainMenuGameState", menuName = "Scriptable Objects/MainMenuGameState")]
public class MainMenuGameState : GameState
{
}
