public interface IDamageable 
{
    public void OnDamageTaken(float damage);
}
