using UnityEngine;

namespace Constants
{
    public class Constants
    {
        
    }
}